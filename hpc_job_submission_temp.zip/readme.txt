Prepare evething before you go to sbatch. These include:
0 prepare well the script of jounal.ext, my_script.sh, pbs_error.out, pbs_output.out; prepare the settings of fluent at somewhere else.
1 swich to a good cluster use module swap
2 change to the working direct use cd command
3 allocate resources use qsub
4 mount the software
5 submit the job use sbatch

$ module swap cluster/golett
$ cd ~/DAF
$ qsub -X -I -l walltime=48:00:00 -l nodes=1:ppn=24
$ module load ANSYS_CFD/2019R1
$ sbatch my_script.sh