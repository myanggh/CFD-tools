#!/bin/bash
;#PBS -l ib				# request nodes with an InfiniBand network, which enables large parallel jobs to run efficiently due to high bandwidth and low latency network
#PBS -N mia3d_sym_0.1m_pbm_euler	# Specify the desired job name
#PBS -l nodes=1:ppn=24			
#PBS -l walltime=24:00:00		# No need to specify the queue anymore
#PBS -o pbs_output.out
#PBS -e pbs_error.out
#PBS -m abe				# mail when beginning, aborting and error message

module load ANSYS_CFD/2019R1

cd $PBS_O_WORKDIR

FLUENT_PPN=24
INPUT_FILE=journal.txt
OUTPUT_FILE=output.txt

FLUENT_HOSTFILE=fluent.hosts.`date +%s`
TMP1_HOSTFILE=tmp1.hosts.`date +%s`
TMP2_HOSTFILE=tmp2.hosts.`date +%s`
cat $PBS_NODEFILE | uniq | sed -e 's/\.gengar.*$//' > $TMP1_HOSTFILE
for ((i=0;i<$FLUENT_PPN;i++)) ; do cat $TMP1_HOSTFILE >> $TMP2_HOSTFILE ; done
cat $TMP2_HOSTFILE | sort > $FLUENT_HOSTFILE
rm $TMP1_HOSTFILE $TMP2_HOSTFILE
export FLUENT_PROCESSES=`cat $FLUENT_HOSTFILE | wc -l`

export NCPUS=`cat $FLUENTHOSTFILE | wc -l`

time fluent -gu -driver null 3ddp -t$FLUENT_PROCESSES -pinfiniband -cnf=$FLUENT_HOSTFILE -ssh <$INPUT_FILE> $OUTPUT_FILE